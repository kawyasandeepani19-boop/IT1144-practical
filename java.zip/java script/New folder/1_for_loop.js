

console.log("--- For Loop Output ---");
for (let i = 1; i <= 5; i++) {
    console.log(i);
}
