let i;
for(let i=0; i<=10; i++){
	console.log("hello world : " +i);	
}



